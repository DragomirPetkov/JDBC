INSERT INTO beers.beers(beer_id, name, abv)
VALUES(1,'Kamenitca',4.5);

INSERT INTO beers.beers(beer_id, name, abv)
VALUES(2,'Zagorka',4.6);

INSERT INTO beers.beers(beer_id, name, abv)
VALUES(3,'Mlado Pivo',4.4);

INSERT INTO beers.beers(beer_id, name, abv)
VALUES(4,'Boliarka',4.7);